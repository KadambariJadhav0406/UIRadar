﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace UIRadarNET.Models;

public partial class User
{
    public long UserId { get; set; }

    public string? Address { get; set; }

    public string? Contact { get; set; }

    public string? Email { get; set; }

    public string? Password { get; set; }

    public string? Pincode { get; set; }

    public string? Role { get; set; }

    public string? UserName { get; set; }

   
    public virtual ICollection<Feedback> Feedbacks { get; set; } = new List<Feedback>();

   
    public virtual ICollection<Payment> Payments { get; set; } = new List<Payment>();

    
    public virtual ICollection<QuestionAnswer> QuestionAnswers { get; set; } = new List<QuestionAnswer>();

   
    public virtual ICollection<ServicePackage> ServicePackages { get; set; } = new List<ServicePackage>();

    
    public virtual ICollection<ServiceRequest> ServiceRequestCustomers { get; set; } = new List<ServiceRequest>();

    
    public virtual ICollection<ServiceRequest> ServiceRequestEngineers { get; set; } = new List<ServiceRequest>();
}
