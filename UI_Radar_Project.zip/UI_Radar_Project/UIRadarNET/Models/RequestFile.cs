﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace UIRadarNET.Models;

public partial class RequestFile
{
    public long FileId { get; set; }

    public byte[] FileData { get; set; } = null!;

    public string? FileRole { get; set; }

    public string? UploadedBy { get; set; }

    public long RequestId { get; set; }

    [JsonIgnore]
    public virtual ServiceRequest Request { get; set; } = null!;
}
