﻿namespace UIRadarNET.Models
{
    public enum Role
    {
        ROLE_ADMIN, ROLE_ENGINEER,ROLE_CUSTOMER
    }
}
