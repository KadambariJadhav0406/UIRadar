﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace UIRadarNET.Models;

public partial class ServicePackage
{
    public long PackageId { get; set; }

    public string? Description { get; set; }

    public string PackageName { get; set; } = null!;

    public double? Price { get; set; }

    public long? EngineerId { get; set; }

    
    public virtual User? Engineer { get; set; }

    [JsonIgnore]
    public virtual ICollection<Payment> Payments { get; set; } = new List<Payment>();
}
