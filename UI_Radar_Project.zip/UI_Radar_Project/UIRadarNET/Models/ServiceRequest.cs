﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace UIRadarNET.Models;

public partial class ServiceRequest
{
    public long RequestId { get; set; }

    public string? Description { get; set; }

    public DateOnly? RequestDate { get; set; }

    public string? Status { get; set; }

    public long CustomerId { get; set; }

    public long EngineerId { get; set; }

    [JsonIgnore]
    public virtual User Customer { get; set; } = null!;

    [JsonIgnore]
    public virtual User Engineer { get; set; } = null!;

    [JsonIgnore]
    public virtual ICollection<RequestFile> RequestFiles { get; set; } = new List<RequestFile>();
}
