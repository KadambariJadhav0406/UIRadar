﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace UIRadarNET.Models;

public partial class QuestionAnswer
{
    public long Id { get; set; }

    public string? Answer { get; set; }

    public bool IsAnswered { get; set; }

    public string Question { get; set; } = null!;

    public long? UserId { get; set; }

    [JsonIgnore]
    public virtual User? User { get; set; }
}
