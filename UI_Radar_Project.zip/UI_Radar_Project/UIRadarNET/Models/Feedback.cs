﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace UIRadarNET.Models;

public partial class Feedback
{
    public long FeedbackId { get; set; }

    public string? Comment { get; set; }

    public long UserId { get; set; }

    [JsonIgnore]
    public virtual User User { get; set; } = null!;
}
