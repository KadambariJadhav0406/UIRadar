﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Pomelo.EntityFrameworkCore.MySql.Scaffolding.Internal;

namespace UIRadarNET.Models;

public partial class UiradarContext : DbContext
{
    public UiradarContext()
    {
    }

    public UiradarContext(DbContextOptions<UiradarContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Feedback> Feedbacks { get; set; }

    public virtual DbSet<Payment> Payments { get; set; }

    public virtual DbSet<QuestionAnswer> QuestionAnswers { get; set; }

    public virtual DbSet<RequestFile> RequestFiles { get; set; }

    public virtual DbSet<ServicePackage> ServicePackages { get; set; }

    public virtual DbSet<ServiceRequest> ServiceRequests { get; set; }

    public virtual DbSet<User> Users { get; set; }


    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder
            .UseCollation("utf8mb4_0900_ai_ci")
            .HasCharSet("utf8mb4");

        modelBuilder.Entity<Feedback>(entity =>
        {
            entity.HasKey(e => e.FeedbackId).HasName("PRIMARY");

            entity.ToTable("feedbacks");

            entity.HasIndex(e => e.UserId, "FK312drfl5lquu37mu4trk8jkwx");

            entity.Property(e => e.FeedbackId).HasColumnName("feedback_id");
            entity.Property(e => e.Comment)
                .HasMaxLength(255)
                .HasColumnName("comment");
            entity.Property(e => e.UserId).HasColumnName("user_id");

            entity.HasOne(d => d.User).WithMany(p => p.Feedbacks)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK312drfl5lquu37mu4trk8jkwx");
        });

        modelBuilder.Entity<Payment>(entity =>
        {
            entity.HasKey(e => e.PaymentId).HasName("PRIMARY");

            entity.ToTable("payments");

            entity.HasIndex(e => e.PackageId, "FK4p0q0sg6g8yk02y5gpftqxtg1");

            entity.HasIndex(e => e.CustomerId, "FKd1qot1f3alweegm6ledjow6nj");

            entity.Property(e => e.PaymentId).HasColumnName("payment_id");
            entity.Property(e => e.Amount)
                .HasPrecision(19, 2)
                .HasColumnName("amount");
            entity.Property(e => e.CustomerId).HasColumnName("customer_id");
            entity.Property(e => e.PackageId).HasColumnName("package_id");
            entity.Property(e => e.PaymentDate)
                .HasMaxLength(6)
                .HasColumnName("payment_date");
            entity.Property(e => e.PaymentStatus)
                .HasMaxLength(255)
                .HasColumnName("payment_status");

            entity.HasOne(d => d.Customer).WithMany(p => p.Payments)
                .HasForeignKey(d => d.CustomerId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FKd1qot1f3alweegm6ledjow6nj");

            entity.HasOne(d => d.Package).WithMany(p => p.Payments)
                .HasForeignKey(d => d.PackageId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK4p0q0sg6g8yk02y5gpftqxtg1");
        });

        modelBuilder.Entity<QuestionAnswer>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("question_answer");

            entity.HasIndex(e => e.UserId, "FKgyqx71niqwvbwi5kmsq5gwm92");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Answer)
                .HasMaxLength(2000)
                .HasColumnName("answer");
            entity.Property(e => e.IsAnswered)
                .HasColumnType("bit(1)")
                .HasColumnName("is_answered");
            entity.Property(e => e.Question)
                .HasMaxLength(2000)
                .HasColumnName("question");
            entity.Property(e => e.UserId).HasColumnName("user_id");

            entity.HasOne(d => d.User).WithMany(p => p.QuestionAnswers)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FKgyqx71niqwvbwi5kmsq5gwm92");
        });

        modelBuilder.Entity<RequestFile>(entity =>
        {
            entity.HasKey(e => e.FileId).HasName("PRIMARY");

            entity.ToTable("request_files");

            entity.HasIndex(e => e.RequestId, "FKmh2oektkkfw4afxk1kodoh3v2");

            entity.Property(e => e.FileId).HasColumnName("file_id");
            entity.Property(e => e.FileData).HasColumnName("file_data");
            entity.Property(e => e.FileRole)
                .HasMaxLength(255)
                .HasColumnName("file_role");
            entity.Property(e => e.RequestId).HasColumnName("request_id");
            entity.Property(e => e.UploadedBy)
                .HasMaxLength(255)
                .HasColumnName("uploaded_by");

            entity.HasOne(d => d.Request).WithMany(p => p.RequestFiles)
                .HasForeignKey(d => d.RequestId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FKmh2oektkkfw4afxk1kodoh3v2");
        });

        modelBuilder.Entity<ServicePackage>(entity =>
        {
            entity.HasKey(e => e.PackageId).HasName("PRIMARY");

            entity.ToTable("service_packages");

            entity.HasIndex(e => e.EngineerId, "FKr3358vqfbmgmctqge9wksst0h");

            entity.Property(e => e.PackageId).HasColumnName("package_id");
            entity.Property(e => e.Description)
                .HasMaxLength(255)
                .HasColumnName("description");
            entity.Property(e => e.EngineerId).HasColumnName("engineer_id");
            entity.Property(e => e.PackageName)
                .HasMaxLength(255)
                .HasColumnName("package_name");
            entity.Property(e => e.Price).HasColumnName("price");

            entity.HasOne(d => d.Engineer).WithMany(p => p.ServicePackages)
                .HasForeignKey(d => d.EngineerId)
                .HasConstraintName("FKr3358vqfbmgmctqge9wksst0h");
        });

        modelBuilder.Entity<ServiceRequest>(entity =>
        {
            entity.HasKey(e => e.RequestId).HasName("PRIMARY");

            entity.ToTable("service_requests");

            entity.HasIndex(e => e.CustomerId, "FK8b99qxwylh17iqr0gqnweoiqw");

            entity.HasIndex(e => e.EngineerId, "FKcdwkbbr7vmgyebvbiigc8qc5o");

            entity.Property(e => e.RequestId).HasColumnName("request_id");
            entity.Property(e => e.CustomerId).HasColumnName("customer_id");
            entity.Property(e => e.Description)
                .HasMaxLength(255)
                .HasColumnName("description");
            entity.Property(e => e.EngineerId).HasColumnName("engineer_id");
            entity.Property(e => e.RequestDate)
                .HasMaxLength(6)
                .HasColumnName("request_date");
            entity.Property(e => e.Status)
                .HasMaxLength(255)
                .HasColumnName("status");

            entity.HasOne(d => d.Customer).WithMany(p => p.ServiceRequestCustomers)
                .HasForeignKey(d => d.CustomerId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK8b99qxwylh17iqr0gqnweoiqw");

            entity.HasOne(d => d.Engineer).WithMany(p => p.ServiceRequestEngineers)
                .HasForeignKey(d => d.EngineerId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FKcdwkbbr7vmgyebvbiigc8qc5o");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("PRIMARY");

            entity.ToTable("users");

            entity.Property(e => e.UserId).HasColumnName("user_id");
            entity.Property(e => e.Address)
                .HasMaxLength(255)
                .HasColumnName("address");
            entity.Property(e => e.Contact)
                .HasMaxLength(255)
                .HasColumnName("contact");
            entity.Property(e => e.Email)
                .HasMaxLength(255)
                .HasColumnName("email");
            entity.Property(e => e.Password)
                .HasMaxLength(255)
                .HasColumnName("password");
            entity.Property(e => e.Pincode)
                .HasMaxLength(255)
                .HasColumnName("pincode");
            entity.Property(e => e.Role)
                .HasMaxLength(255)
                .HasColumnName("role");
            entity.Property(e => e.UserName)
                .HasMaxLength(255)
                .HasColumnName("user_name");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
