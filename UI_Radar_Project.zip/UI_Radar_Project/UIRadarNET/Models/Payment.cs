﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace UIRadarNET.Models;

public partial class Payment
{
    public long PaymentId { get; set; }

    public decimal? Amount { get; set; }

    public DateOnly? PaymentDate { get; set; }

    public string? PaymentStatus { get; set; }

    public long CustomerId { get; set; }

    public long PackageId { get; set; }

    [JsonIgnore]
    public virtual User Customer { get; set; } = null!;

    [JsonIgnore]
    public virtual ServicePackage Package { get; set; } = null!;
}
