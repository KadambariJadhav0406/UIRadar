﻿using UIRadarNET.Models;

namespace UIRadarNET.Repositories
{
    public interface IUserRepository
    {
        Task<User> FindByEmail(string email);
        Task<User> AddUserAsync(User user);
        Task<IEnumerable<User>> GetAllEngineersAsync();
        Task<List<User>> GetAllUsersAsync();
        Task<User?> GetUserByIdAsync(long userId);
        Task<User?> GetUserByEmailAsync(string email);

        Task<User> RegisterUserAsync(User user);
        Task<User> UpdateUserAsync(long id, User user);
        Task<List<User>> GetEngineersByCustomerIdAsync(long customerId);
    }
}
