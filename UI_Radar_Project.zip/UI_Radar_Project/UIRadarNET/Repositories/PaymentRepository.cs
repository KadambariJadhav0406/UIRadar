﻿using Microsoft.EntityFrameworkCore;
using UIRadarNET.DTO;
using UIRadarNET.Models;

namespace UIRadarNET.Repositories
{
    public class PaymentRepository : IPaymentRepository
    {

        private readonly UiradarContext _context;

        public PaymentRepository(UiradarContext context)
        {
            _context = context;
        }

        public async Task<Payment> AddPaymentAsync(Payment payment)
        {
            _context.Payments.Add(payment);
            await _context.SaveChangesAsync();
            return payment;
        }

        public async Task<List<PaymentHistoryDTO>> GetAllPaymentHistoryAsync()
        {
            return await _context.Payments
                .Include(p => p.Customer)
                .Include(p => p.Package)
                .Select(p => new PaymentHistoryDTO
                {
                    PaymentId = p.PaymentId,
                    PaymentDate = p.PaymentDate,
                    CustomerName = p.Customer.UserName,
                    PackageName = p.Package.PackageName,
                    Amount = p.Amount,
                    PaymentStatus = p.PaymentStatus
                })
                .ToListAsync();
        }

        public async Task<List<PaymentHistoryDTO>> GetPaymentHistoryByCustomerIdAsync(long customerId)
        {
            return await _context.Payments
                .Where(p => p.CustomerId == customerId)
                .Include(p => p.Customer)
                .Include(p => p.Package)
                .Select(p => new PaymentHistoryDTO
                {
                    PaymentId = p.PaymentId,
                    PaymentDate = p.PaymentDate,
                    CustomerName = p.Customer.UserName,
                    PackageName = p.Package.PackageName,
                    Amount = p.Amount,
                    PaymentStatus = p.PaymentStatus
                })
                .ToListAsync();
        }
    }
}
