﻿using Microsoft.EntityFrameworkCore;
using System;
using UIRadarNET.Models;

namespace UIRadarNET.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly UiradarContext _context;

        public UserRepository(UiradarContext context)
        {
            _context = context;
        }

        public async Task<User> FindByEmail(string email)
        {
            return await _context.Users.FirstOrDefaultAsync(u => u.Email == email);
        }

        public async Task<User> AddUserAsync(User user)
        {
            _context.Users.Add(user);
            await _context.SaveChangesAsync();
            return user;
        }

        public async Task<IEnumerable<User>> GetAllEngineersAsync()
        {
            return await _context.Users
                .Where(u => u.Role == "ROLE_ENGINEER")
                .ToListAsync();
        }

        public async Task<User?> GetUserByIdAsync(long userId)
        {
            return await _context.Users.FindAsync(userId);
        }

        public async Task<User?> GetUserByEmailAsync(string email)
        {
            return await _context.Users
                .FirstOrDefaultAsync(u => u.Email == email);
        }

        public async Task<User> UpdateUserAsync(long id, User updatedUser)
        {
            var existingUser = await _context.Users.FindAsync(id);
            if (existingUser == null) return null;

            existingUser.UserName = updatedUser.UserName;
            existingUser.Email = updatedUser.Email;
            existingUser.Contact = updatedUser.Contact;
            existingUser.Address = updatedUser.Address;
            existingUser.Pincode = updatedUser.Pincode;
            existingUser.Password = updatedUser.Password;
            existingUser.Role = updatedUser.Role;

            await _context.SaveChangesAsync();
            return existingUser;
        }

        public async Task<List<User>> GetAllUsersAsync()
        {
            return await _context.Users.ToListAsync();
        }

        public async Task<User> RegisterUserAsync(User user)
        {
            _context.Users.Add(user);
            await _context.SaveChangesAsync();
            return user;
        }

        public async Task<List<User>> GetEngineersByCustomerIdAsync(long customerId)
        {
            // 1. Get package IDs for which the customer has payments (any payment status)
            var packageIds = await _context.Payments
                .Where(p => p.CustomerId == customerId)
                .Select(p => p.PackageId)
                .Distinct()
                .ToListAsync();

            if (!packageIds.Any())
                return new List<User>();

            // 2. Get engineer IDs assigned to those packages from ServicePackage
            var engineerIds = await _context.ServicePackages
                .Where(sp => packageIds.Contains(sp.PackageId) && sp.EngineerId != null)
                .Select(sp => sp.EngineerId.Value)
                .Distinct()
                .ToListAsync();

            if (!engineerIds.Any())
                return new List<User>();

            // 3. Get engineer user details by their user IDs
            var engineers = await _context.Users
                .Where(u => engineerIds.Contains(u.UserId))
                .ToListAsync();

            return engineers;
        }

    }
}
