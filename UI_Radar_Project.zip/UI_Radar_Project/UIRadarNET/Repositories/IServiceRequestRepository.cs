﻿using UIRadarNET.DTO;
using UIRadarNET.Models;

namespace UIRadarNET.Repositories
{
    public interface IServiceRequestRepository
    {
        Task<ServiceRequest> AddServiceRequestAsync(ServiceRequest request);
        Task<RequestFile> AddRequestFileAsync(RequestFile file);

        Task<List<EngineerServiceRequestDTO>> GetRequestsForEngineerAsync(long engineerId);

        Task<IEnumerable<ServiceRequest>> GetRequestsByCustomerIdAsync(long customerId);
    }
}
