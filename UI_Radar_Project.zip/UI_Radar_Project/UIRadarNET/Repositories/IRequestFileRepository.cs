﻿using UIRadarNET.Models;

namespace UIRadarNET.Repositories
{
    public interface IRequestFileRepository
    {
        Task<RequestFile?> GetFileByIdAsync(long requestId);

        Task<RequestFile?> GetEngineerFileByIdAsync(long requestId);

        Task AddRequestFileAsync(RequestFile requestFile);
        Task SaveChangesAsync();

        Task<RequestFile?> GetFileByRequestIdAndUploaderAsync(long requestId, string uploadedBy);

        Task<ServiceRequest?> GetServiceRequestByIdAsync(long requestId);
    }
}
