﻿using Microsoft.EntityFrameworkCore;
using System;
using UIRadarNET.DTO;
using UIRadarNET.Models;

namespace UIRadarNET.Repositories
{
    public class PackageRepository : IPackageRepository
    {
        private readonly UiradarContext _context;

        public PackageRepository(UiradarContext context)
        {
            _context = context;
        }

        public async Task<ServicePackage> AddPackageAsync(ServicePackage package)
        {
            _context.ServicePackages.Add(package);
            await _context.SaveChangesAsync();
            return package;
        }

        public IEnumerable<PackageDTO> GetAllPackages()
        {
            return _context.ServicePackages
         .Include(p => p.Engineer) // Load the Engineer navigation property
         .Select(p => new PackageDTO
         {
             PackageId = p.PackageId,
             Description = p.Description,
             PackageName = p.PackageName,
             Price = p.Price,
             EngineerId = p.EngineerId,
             EngineerName = p.Engineer != null ? p.Engineer.UserName : null
         })
         .ToList();
        }

        public async Task<ServicePackage?> GetPackageByIdAsync(long id)
        {
            return await _context.ServicePackages.FindAsync(id);
        }

        public async Task UpdatePackageAsync(ServicePackage package)
        {
            _context.ServicePackages.Update(package);
            await _context.SaveChangesAsync();
        }

        public async Task<ServicePackage?> GetByIdAsync(long id)
        {
            return await _context.ServicePackages
                .Include(p => p.Engineer) // Include Engineer details
                .FirstOrDefaultAsync(p => p.PackageId == id);
        }
    }
}
