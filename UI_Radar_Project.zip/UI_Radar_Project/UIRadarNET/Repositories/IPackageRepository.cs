﻿using UIRadarNET.DTO;
using UIRadarNET.Models;

namespace UIRadarNET.Repositories
{
    public interface IPackageRepository
    {
        Task<ServicePackage> AddPackageAsync(ServicePackage package);

        IEnumerable<PackageDTO> GetAllPackages();

        Task<ServicePackage?> GetByIdAsync(long id);
        Task UpdatePackageAsync(ServicePackage package);
    }
}
