﻿using Microsoft.EntityFrameworkCore;
using UIRadarNET.DTO;
using UIRadarNET.Models;

namespace UIRadarNET.Repositories
{
    public class ServiceRequestRepository : IServiceRequestRepository
    {
        private readonly UiradarContext _context;

        public ServiceRequestRepository(UiradarContext context)
        {
            _context = context;
        }

        public async Task<ServiceRequest> AddServiceRequestAsync(ServiceRequest request)
        {
            _context.ServiceRequests.Add(request);
            await _context.SaveChangesAsync();
            return request;
        }

        public async Task<RequestFile> AddRequestFileAsync(RequestFile file)
        {
            _context.RequestFiles.Add(file);
            await _context.SaveChangesAsync();
            return file;
        }

        public async Task<List<EngineerServiceRequestDTO>> GetRequestsForEngineerAsync(long engineerId)
        {
            return await _context.ServiceRequests
                .Where(r => r.EngineerId == engineerId)
                .Select(r => new EngineerServiceRequestDTO
                {
                    RequestId = r.RequestId,
                    Description = r.Description,
                    RequestDate = r.RequestDate,
                    Status = r.Status,
                    CustomerFile = r.RequestFiles
                        .Where(f => f.UploadedBy == "Customer")
                        .Select(f => f.FileData)
                        .FirstOrDefault()
                })
                .ToListAsync();
        }

        public async Task<IEnumerable<ServiceRequest>> GetRequestsByCustomerIdAsync(long customerId)
        {
            return await _context.ServiceRequests
                                 .Where(r => r.CustomerId == customerId)
                                 .ToListAsync();
        }
    }
}
