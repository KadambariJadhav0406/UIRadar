﻿using UIRadarNET.DTO;
using UIRadarNET.Models;

namespace UIRadarNET.Repositories
{
    public interface IPaymentRepository
    {
        Task<Payment> AddPaymentAsync(Payment payment);

        Task<List<PaymentHistoryDTO>> GetAllPaymentHistoryAsync();

        Task<List<PaymentHistoryDTO>> GetPaymentHistoryByCustomerIdAsync(long customerId);
    }
}
