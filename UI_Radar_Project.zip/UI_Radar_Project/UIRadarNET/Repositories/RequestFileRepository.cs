﻿using Microsoft.EntityFrameworkCore;
using UIRadarNET.Models;

namespace UIRadarNET.Repositories
{
    public class RequestFileRepository : IRequestFileRepository
    {
        private readonly UiradarContext _context;

        public RequestFileRepository(UiradarContext context)
        {
            _context = context;
        }

        public async Task<RequestFile?> GetFileByIdAsync(long requestId)
        {
            return await _context.RequestFiles
            .FirstOrDefaultAsync(f => f.RequestId == requestId && f.UploadedBy == "Customer");

        }

        public async Task<RequestFile?> GetEngineerFileByIdAsync(long requestId)
        {
            return await _context.RequestFiles
            .FirstOrDefaultAsync(f => f.RequestId == requestId && f.UploadedBy == "Engineer");
        }

        public async Task AddRequestFileAsync(RequestFile requestFile)
        {
            await _context.RequestFiles.AddAsync(requestFile);
        }

        public async Task SaveChangesAsync()
        {
            await _context.SaveChangesAsync();
        }

        public async Task<RequestFile?> GetFileByRequestIdAndUploaderAsync(long requestId, string uploadedBy)
        {
            return await _context.RequestFiles
                .FirstOrDefaultAsync(rf => rf.RequestId == requestId && rf.UploadedBy == uploadedBy);
        }

        public async Task<ServiceRequest?> GetServiceRequestByIdAsync(long requestId)
        {
            return await _context.ServiceRequests
                                 .FirstOrDefaultAsync(sr => sr.RequestId == requestId);
        }
    }
}
