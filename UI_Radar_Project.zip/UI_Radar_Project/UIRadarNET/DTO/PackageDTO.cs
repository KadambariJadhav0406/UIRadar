﻿namespace UIRadarNET.DTO
{
    public class PackageDTO
    {
        public long PackageId { get; set; }
        public string? Description { get; set; }
        public string PackageName { get; set; }
        public double? Price { get; set; }
        public long? EngineerId { get; set; }
        public string EngineerName { get; set; }
    }
}
