﻿namespace UIRadarNET.DTO
{
    public class EngineerServiceRequestDTO
    {
        public long RequestId { get; set; }
        public string? Description { get; set; }
        public DateOnly? RequestDate { get; set; }
        public string? Status { get; set; }
        public byte[]? CustomerFile { get; set; }
    }
}
