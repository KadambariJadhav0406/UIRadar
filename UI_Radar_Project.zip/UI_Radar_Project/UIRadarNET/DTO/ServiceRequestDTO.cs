﻿namespace UIRadarNET.DTO
{
    public class ServiceRequestDTO
    {
        public long CustomerId { get; set; }
        public long EngineerId { get; set; }
        public string Description { get; set; }
        public IFormFile File { get; set; }
    }
}
