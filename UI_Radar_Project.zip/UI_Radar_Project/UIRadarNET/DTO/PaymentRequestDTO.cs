﻿namespace UIRadarNET.DTO
{
    public class PaymentRequestDTO
    {
        public long PackageId { get; set; }
        public decimal Amount { get; set; }
        public long CustomerId { get; set; }
    }
}
