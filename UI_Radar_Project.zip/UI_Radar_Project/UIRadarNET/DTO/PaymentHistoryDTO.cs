﻿namespace UIRadarNET.DTO
{
    public class PaymentHistoryDTO
    {
        public long PaymentId { get; set; }
        public DateOnly? PaymentDate { get; set; }
        public string? CustomerName { get; set; }
        public string? PackageName { get; set; }
        public decimal? Amount { get; set; }
        public string? PaymentStatus { get; set; }
    }
}
