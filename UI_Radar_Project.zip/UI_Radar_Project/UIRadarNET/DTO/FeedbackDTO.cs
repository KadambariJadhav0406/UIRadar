﻿namespace UIRadarNET.DTO
{
    public class FeedbackDTO
    {
        public long FeedbackId { get; set; }
        public string UserName { get; set; }
        public string Comment { get; set; }
    }

}
