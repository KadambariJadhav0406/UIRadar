﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UIRadarNET.DTO;
using UIRadarNET.Models;
using UIRadarNET.Services;

namespace UIRadarNET.Controllers
{
    [Route("package")]
    [ApiController]
    public class PackageController : ControllerBase
    {
        private readonly IPackageService _packageService;
        private readonly IServiceRequestService _service;

        public PackageController(IPackageService packageService, IServiceRequestService service)
        {
            _packageService = packageService;
            _service = service;
        }

        [Authorize]
        [HttpPost("createPackage")]
        public async Task<IActionResult> CreatePackage([FromBody] ServicePackage package)
        {
            var createdPackage = await _packageService.CreatePackageAsync(package);
            return Ok(createdPackage);
        }

        
        [HttpGet("getAllPackages")]
        public ActionResult<IEnumerable<PackageDTO>> GetAllPackages()
        {
            var packages = _packageService.ViewAllPackages();
            return Ok(packages);
        }

        [Authorize]
        [HttpPost("createServiceRequest")]
        public async Task<IActionResult> CreateServiceRequest([FromForm] ServiceRequestDTO dto)
        {
            var result = await _service.CreateServiceRequestAsync(dto);
            return Ok(new
            {
                message = "Service request created successfully",
                requestId = result.RequestId
            });
        }

        [Authorize]
        [HttpGet("getPackageById/{id}")]
        public async Task<IActionResult> GetPackageById(long id)
        {
            var package = await _packageService.GetPackageByIdAsync(id);
            if (package == null)
                return NotFound(new { message = "Package not found" });

            return Ok(new
            {
                package.PackageId,
                package.PackageName,
                package.Description,
                package.Price,
                EngineerName = package.Engineer?.UserName
            });
        }

        [Authorize]
        [HttpPut("updatePackageById/{id}")]
        public async Task<IActionResult> EditPackage(long id, [FromBody] ServicePackage updatedPackage)
        {
            var isUpdated = await _packageService.UpdatePackageAsync(id, updatedPackage);
            if (!isUpdated)
                return NotFound(new { message = "Package not found" });

            return Ok(new { message = "Package updated successfully" });
        }


    }
}
