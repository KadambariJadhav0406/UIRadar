﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UIRadarNET.DTO;
using UIRadarNET.Services;

namespace UIRadarNET.Controllers
{
    [Route("serviceRequest")]
    [ApiController]
    public class ServiceRequestController : ControllerBase
    {
        private readonly IServiceRequestService _service;

        public ServiceRequestController(IServiceRequestService service)
        {
            _service = service;
        }

        [Authorize]
        [HttpPost("create")]
        public async Task<IActionResult> CreateServiceRequest([FromForm] ServiceRequestDTO dto)
        {
            var result = await _service.CreateServiceRequestAsync(dto);
            return Ok(new
            {
                message = "Service request created successfully",
                requestId = result.RequestId
            });
        }

        [Authorize]
        [HttpGet("engineer/{engineerId}")]
        public async Task<IActionResult> GetEngineerRequests(long engineerId)
        {
            var requests = await _service.GetEngineerRequestsAsync(engineerId);

            if (!requests.Any())
                return NotFound(new { message = "No service requests found for this engineer." });

            return Ok(requests);
        }

        [Authorize]
        [HttpGet("customer/{customerId}")]
        public async Task<IActionResult> GetRequestsByCustomerId(long customerId)
        {
            var requests = await _service.GetRequestsByCustomerIdAsync(customerId);
            if (requests == null || !requests.Any())
                return NotFound($"No service requests found for customer id {customerId}");

            return Ok(requests);
        }
    }
}
