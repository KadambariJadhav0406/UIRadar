﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UIRadarNET.DTO;
using UIRadarNET.Services;

namespace UIRadarNET.Controllers
{
    [Route("")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        private readonly IPaymentService _paymentService;

        public PaymentController(IPaymentService paymentService)
        {
            _paymentService = paymentService;
        }

        [Authorize]
        [HttpPost("makePayment")]
        public async Task<IActionResult> MakePayment([FromBody] PaymentRequestDTO request)
        {
            if (request.Amount <= 0)
                return BadRequest("Invalid amount.");

            var payment = await _paymentService.MakePaymentAsync(request.PackageId, request.Amount, request.CustomerId);
            return Ok(payment);
        }

        [Authorize]
        [HttpGet("getAllPayments")]
        public async Task<IActionResult> GetPaymentHistory()
        {
            var history = await _paymentService.GetAllPaymentHistoryAsync();
            return Ok(history);
        }

        [Authorize]
        [HttpGet("customer/getPayment/{customerId}")]
        public async Task<IActionResult> GetPaymentHistoryByCustomer(long customerId)
        {
            var payments = await _paymentService.GetPaymentHistoryByCustomerIdAsync(customerId);
            if (payments == null || !payments.Any())
                return NotFound($"No payments found for CustomerId {customerId}");

            return Ok(payments);
        }
    }
}
