﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UIRadarNET.DTO;
using UIRadarNET.Models;
using UIRadarNET.Services;

namespace UIRadarNET.Controllers
{
    [Route("customer")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly IUserService _userService;

        public CustomerController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpPost("registerCustomer")]
        public async Task<IActionResult> RegisterUser([FromBody] UserDTO user)
        {
            var createdUser = await _userService.RegisterUserAsync(user);
            return Ok(createdUser);
        }

        [Authorize]
        [HttpPut("updateUser/{id}")]
        public async Task<IActionResult> UpdateUser(long id, [FromBody] User user)
        {
            try
            {
                user.Role = "ROLE_CUSTOMER";

                var updatedUser = await _userService.UpdateUserAsync(id, user);
                if (updatedUser == null)
                    return NotFound("User not found");

                return Ok(updatedUser);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error updating user: {ex.Message}");
            }
        }

        [Authorize]
        [HttpGet("getAllUsers")]
        public async Task<IActionResult> GetAllUsers()
        {
            try
            {
                var users = await _userService.GetAllUsersAsync();
                return Ok(users);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error fetching users: {ex.Message}");
            }
        }

        [Authorize]
        [HttpGet("getUserById/{id}")]
        public async Task<IActionResult> GetUserById(long id)
        {
            try
            {
                var user = await _userService.GetUserByIdAsync(id);
                if (user == null)
                    return NotFound("User not found");

                return Ok(user);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error fetching user: {ex.Message}");
            }
        }

        [HttpGet("engineersByCustomer/{customerId}")]
        public async Task<IActionResult> GetEngineersByCustomer(long customerId)
        {
            var engineers = await _userService.GetEngineersForCustomerAsync(customerId);

            if (engineers == null || !engineers.Any())
                return NotFound("No engineers found for the given customer.");

            // Return only necessary engineer info to frontend
            var result = engineers.Select(e => new {
                e.UserId,
                e.UserName,
                e.Email,
                e.Contact
            });

            return Ok(result);
        }
    }
}
