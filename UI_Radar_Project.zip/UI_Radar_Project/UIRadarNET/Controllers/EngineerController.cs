﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace UIRadarNET.Controllers
{
    [Route("engineer")]
    [ApiController]
    public class EngineerController : ControllerBase
    {
    }
}
