﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UIRadarNET.DTO;
using UIRadarNET.Models;
using UIRadarNET.Services;

namespace UIRadarNET.Controllers
{
    [Route("admin")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly IUserService _userService;

        public AdminController(IUserService userService)
        {
            _userService = userService;
        }

        [Authorize]
        [HttpPost("registerEngineer")]
        public async Task<IActionResult> RegisterUser([FromBody] UserDTO user)
        {
            var createdUser = await _userService.RegisterEngineerAsync(user);
            return Ok(createdUser);
        }

        [Authorize]
        [HttpGet("getAllEngineers")]
        public async Task<IActionResult> GetAllEngineers()
        {
            var engineers = await _userService.GetAllEngineersAsync();
            return Ok(engineers);
        }
    }
}
