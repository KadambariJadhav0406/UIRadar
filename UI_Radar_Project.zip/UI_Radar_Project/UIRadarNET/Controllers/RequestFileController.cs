﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UIRadarNET.Services;

namespace UIRadarNET.Controllers
{
    [Route("")]
    [ApiController]
    public class RequestFileController : ControllerBase
    {
        private readonly IRequestFileService _service;

        public RequestFileController(IRequestFileService service)
        {
            _service = service;
        }

        [Authorize]
        [HttpGet("download/customerFile/{requestId}")]
        public async Task<IActionResult> GetFileById(long requestId)
        {
            var fileData = await _service.GetFileByIdAsync(requestId);

            if (fileData == null)
                return NotFound();

            var fileBytes = fileData.FileData;

            // Use original filename if available, else fallback to generic name
            var fileName = !string.IsNullOrEmpty(fileData.FileRole) ? fileData.FileRole : $"file_{requestId}";

            // Determine content type based on extension or store it in DB if possible
            string contentType = "application/octet-stream"; // default fallback

            if (!string.IsNullOrEmpty(fileName))
            {
                var ext = Path.GetExtension(fileName).ToLowerInvariant();
                switch (ext)
                {
                    case ".jpg":
                    case ".jpeg":
                        contentType = "image/jpeg";
                        break;
                    case ".png":
                        contentType = "image/png";
                        break;
                    case ".gif":
                        contentType = "image/gif";
                        break;
                    case ".pdf":
                        contentType = "application/pdf";
                        break;
                    case ".doc":
                        contentType = "application/msword";
                        break;
                    case ".docx":
                        contentType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                        break;
                    // add more if needed
                    default:
                        contentType = "application/octet-stream";
                        break;
                }
            }

            return File(fileBytes, contentType, fileName);
        }


        [Authorize]
        [HttpPost("uploadFileByEngineer/{requestId}")]
        public async Task<IActionResult> UploadFile(long requestId, IFormFile file)
        {
            if (file == null)
                return BadRequest("No file uploaded.");

            try
            {
                await _service.UploadFileAsync(requestId, file, "Engineer");
                return Ok("File uploaded successfully.");
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Authorize]
        [HttpGet("download/engineerFile/{requestId}")]
        public async Task<IActionResult> DownloadFile(long requestId)
        {
            var fileData = await _service.GetEngineerFileByIdAsync(requestId);

            if (fileData == null)
                return NotFound();

            var fileBytes = fileData.FileData;

            // Use original filename if available, else fallback to generic name
            var fileName = !string.IsNullOrEmpty(fileData.FileRole) ? fileData.FileRole : $"file_{requestId}";

            // Determine content type based on extension or store it in DB if possible
            string contentType = "application/octet-stream"; // default fallback

            if (!string.IsNullOrEmpty(fileName))
            {
                var ext = Path.GetExtension(fileName).ToLowerInvariant();
                switch (ext)
                {
                    case ".jpg":
                    case ".jpeg":
                        contentType = "image/jpeg";
                        break;
                    case ".png":
                        contentType = "image/png";
                        break;
                    case ".gif":
                        contentType = "image/gif";
                        break;
                    case ".pdf":
                        contentType = "application/pdf";
                        break;
                    case ".doc":
                        contentType = "application/msword";
                        break;
                    case ".docx":
                        contentType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                        break;
                    // add more if needed
                    default:
                        contentType = "application/octet-stream";
                        break;
                }
            }

            return File(fileBytes, contentType, fileName);
        }    

    }
}
