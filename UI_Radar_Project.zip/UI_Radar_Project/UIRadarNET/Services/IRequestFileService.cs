﻿using UIRadarNET.Models;

namespace UIRadarNET.Services
{
    public interface IRequestFileService
    {
        Task<RequestFile?> GetFileByIdAsync(long requestId);
        Task<RequestFile?> GetEngineerFileByIdAsync(long requestId);

        Task UploadFileAsync(long requestId, IFormFile file, string uploadedBy);

        Task<RequestFile?> GetFileForDownloadAsync(long requestId, string uploadedBy);
    }
}
