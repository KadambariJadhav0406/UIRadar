﻿using Microsoft.AspNetCore.Identity;
using UIRadarNET.DTO;
using UIRadarNET.Models;
using UIRadarNET.Repositories;

namespace UIRadarNET.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;
        private readonly IPasswordHasher<User> _passwordHasher;

        public UserService(IUserRepository userRepository, IPasswordHasher<User> passwordHasher)
        {
            _userRepository = userRepository;
            _passwordHasher = passwordHasher;
        }

        public async Task<User> RegisterUserAsync(UserDTO userDto)
        {
            // Check if email already exists
            var existingUser = await _userRepository.FindByEmail(userDto.Email);
            if (existingUser != null)
            {
                throw new System.Exception("Email already registered");
            }

            var newUser = new User
            {
                UserName = userDto.UserName,
                Email = userDto.Email,
                Contact = userDto.Contact,
                Pincode = userDto.Pincode,
                Address = userDto.Address,
                Role = Role.ROLE_CUSTOMER.ToString(), // Role is set here
            };
            newUser.Password = _passwordHasher.HashPassword(newUser, userDto.Password);

            await _userRepository.AddUserAsync(newUser);
            return newUser;
        }


        public async Task<User> RegisterEngineerAsync(UserDTO userDto)
        {
            // Check if email already exists
            var existingUser = await _userRepository.FindByEmail(userDto.Email);
            if (existingUser != null)
            {
                throw new System.Exception("Email already registered");
            }

            var newUser = new User
            {
                UserName = userDto.UserName,
                Email = userDto.Email,
                Contact = userDto.Contact,
                Pincode = userDto.Pincode,
                Address = userDto.Address,
                Role = Role.ROLE_ENGINEER.ToString(), // Role is set here
            };
            newUser.Password = _passwordHasher.HashPassword(newUser, userDto.Password);

            await _userRepository.AddUserAsync(newUser);
            return newUser;
        }

        public async Task<IEnumerable<User>> GetAllEngineersAsync()
        {
            return await _userRepository.GetAllEngineersAsync();
        }

        public async Task<User> UpdateUserAsync(long id, User user)
        {
            user.Password = _passwordHasher.HashPassword(user, user.Password);
            return await _userRepository.UpdateUserAsync(id, user);
        }

        public async Task<List<User>> GetAllUsersAsync()
        {
            return await _userRepository.GetAllUsersAsync();
        }

        public async Task<User> GetUserByIdAsync(long id)
        {
            return await _userRepository.GetUserByIdAsync(id);
        }

        public async Task<User?> Authenticate(string email, string password)
        {
            var user = await _userRepository.GetUserByEmailAsync(email);
            if (user == null)
            {
                return null;

            }

            Console.WriteLine($"Email: {email}");
            Console.WriteLine($"User from DB: {user?.Email}");
            Console.WriteLine($"Stored Hash: {user?.Password}");
            Console.WriteLine($"Entered password: {password}");

            var result = _passwordHasher.VerifyHashedPassword(user, user.Password, password);
            Console.WriteLine($"Verify result: {result}");

            return result == PasswordVerificationResult.Success ? user : null;
        }

        public async Task<List<User>> GetEngineersForCustomerAsync(long customerId)
        {
            return await _userRepository.GetEngineersByCustomerIdAsync(customerId);
        }
    }
}
