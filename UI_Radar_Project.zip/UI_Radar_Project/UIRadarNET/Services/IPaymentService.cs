﻿using UIRadarNET.DTO;
using UIRadarNET.Models;

namespace UIRadarNET.Services
{
    public interface IPaymentService
    {
        Task<Payment> MakePaymentAsync(long packageId, decimal amount, long customerId);

        Task<List<PaymentHistoryDTO>> GetAllPaymentHistoryAsync();

        Task<List<PaymentHistoryDTO>> GetPaymentHistoryByCustomerIdAsync(long customerId);
    }
}
