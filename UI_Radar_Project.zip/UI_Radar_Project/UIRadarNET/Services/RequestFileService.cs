﻿using UIRadarNET.Models;
using UIRadarNET.Repositories;

namespace UIRadarNET.Services
{
    public class RequestFileService : IRequestFileService
    {
        private readonly IRequestFileRepository _repository;

        public RequestFileService(IRequestFileRepository repository)
        {
            _repository = repository;
        }

        public async Task<RequestFile?> GetFileByIdAsync(long requestId)
        {
            
            var file = await _repository.GetFileByIdAsync(requestId);

            if (file == null)
                throw new FileNotFoundException("File not found or not uploaded by Customer");

            return file;
        }

        public async Task<RequestFile?> GetEngineerFileByIdAsync(long requestId)
        {
            var file = await _repository.GetFileByIdAsync(requestId);

            if (file == null)
                throw new FileNotFoundException("File not found or not uploaded by Customer");

            return file;
        }

        public async Task UploadFileAsync(long requestId, IFormFile file, string uploadedBy)
        {
            if (file == null || file.Length == 0)
                throw new ArgumentException("File is empty");

            using var ms = new MemoryStream();
            await file.CopyToAsync(ms);

            var requestFile = new RequestFile
            {
                FileData = ms.ToArray(),
                FileRole = file.FileName,  
                UploadedBy = uploadedBy,
                RequestId = requestId
            };

            await _repository.AddRequestFileAsync(requestFile);

            // Update ServiceRequest status to "Completed"
            var serviceRequest = await _repository.GetServiceRequestByIdAsync(requestId);
            if (serviceRequest == null)
                throw new Exception("ServiceRequest not found.");

            serviceRequest.Status = "Completed";

            await _repository.SaveChangesAsync();
        }

        public async Task<RequestFile?> GetFileForDownloadAsync(long requestId, string uploadedBy)
        {
            return await _repository.GetFileByRequestIdAndUploaderAsync(requestId, uploadedBy);
        }
    }
}
