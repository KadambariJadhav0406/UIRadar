﻿using UIRadarNET.DTO;
using UIRadarNET.Models;

namespace UIRadarNET.Services
{
    public interface IPackageService
    {
        Task<ServicePackage> CreatePackageAsync(ServicePackage package);

        IEnumerable<PackageDTO> ViewAllPackages();

        Task<bool> UpdatePackageAsync(long id, ServicePackage updatedPackage);

        Task<ServicePackage?> GetPackageByIdAsync(long id);
    }
}       
