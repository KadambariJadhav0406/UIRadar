﻿using UIRadarNET.DTO;
using UIRadarNET.Models;

namespace UIRadarNET.Services
{
    public interface IUserService
    {
        Task<User> RegisterUserAsync(UserDTO user);

        Task<User> RegisterEngineerAsync(UserDTO user);

        Task<IEnumerable<User>> GetAllEngineersAsync();

        Task<User> UpdateUserAsync(long id, User user);
        Task<List<User>> GetAllUsersAsync();
        Task<User> GetUserByIdAsync(long id);

        Task<User?> Authenticate(string email, string password);

        Task<List<User>> GetEngineersForCustomerAsync(long customerId);
    }
}
