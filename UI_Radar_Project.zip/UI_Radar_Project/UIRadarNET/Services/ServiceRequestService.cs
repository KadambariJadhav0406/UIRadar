﻿using UIRadarNET.DTO;
using UIRadarNET.Models;
using UIRadarNET.Repositories;

namespace UIRadarNET.Services
{
    public class ServiceRequestService : IServiceRequestService
    {
        private readonly IServiceRequestRepository _repository;

        public ServiceRequestService(IServiceRequestRepository repository)
        {
            _repository = repository;
        }

        public async Task<ServiceRequest> CreateServiceRequestAsync(ServiceRequestDTO dto)
        {
            // Create main service request
            var request = new ServiceRequest
            {
                CustomerId = dto.CustomerId,
                EngineerId = dto.EngineerId,
                Description = dto.Description,
                RequestDate = DateOnly.FromDateTime(DateTime.Now),
                Status = "Pending"
            };

            await _repository.AddServiceRequestAsync(request);

            // Save file if present
            if (dto.File != null && dto.File.Length > 0)
            {
                using var memoryStream = new MemoryStream();
                await dto.File.CopyToAsync(memoryStream);

                var requestFile = new RequestFile
                {
                    FileData = memoryStream.ToArray(),
                    FileRole = dto.File.FileName,
                    UploadedBy = "Customer",
                    RequestId = request.RequestId
                };

                await _repository.AddRequestFileAsync(requestFile);
            }

            return request;
        }


        public async Task<List<EngineerServiceRequestDTO>> GetEngineerRequestsAsync(long engineerId)
        {
            return await _repository.GetRequestsForEngineerAsync(engineerId);
        }

        public async Task<IEnumerable<ServiceRequest>> GetRequestsByCustomerIdAsync(long customerId)
        {
            return await _repository.GetRequestsByCustomerIdAsync(customerId);
        }
    }
}
