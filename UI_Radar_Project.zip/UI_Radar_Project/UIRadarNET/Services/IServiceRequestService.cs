﻿using UIRadarNET.DTO;
using UIRadarNET.Models;

namespace UIRadarNET.Services
{
    public interface IServiceRequestService
    {
        Task<ServiceRequest> CreateServiceRequestAsync(ServiceRequestDTO dto);

        Task<List<EngineerServiceRequestDTO>> GetEngineerRequestsAsync(long engineerId);

        Task<IEnumerable<ServiceRequest>> GetRequestsByCustomerIdAsync(long customerId);
    }
}
