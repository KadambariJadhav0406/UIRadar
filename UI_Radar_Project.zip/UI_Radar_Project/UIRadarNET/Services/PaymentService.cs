﻿using UIRadarNET.DTO;
using UIRadarNET.Models;
using UIRadarNET.Repositories;

namespace UIRadarNET.Services
{
    public class PaymentService : IPaymentService
    {
        private readonly IPaymentRepository _paymentRepository;

        public PaymentService(IPaymentRepository paymentRepository)
        {
            _paymentRepository = paymentRepository;
        }

        public async Task<Payment> MakePaymentAsync(long packageId, decimal amount, long customerId)
        {
            var payment = new Payment
            {
                Amount = amount,
                PaymentDate = DateOnly.FromDateTime(DateTime.Now),
                PaymentStatus = "Paid",
                CustomerId = customerId,
                PackageId = packageId
            };

            return await _paymentRepository.AddPaymentAsync(payment);
        }

        public async Task<List<PaymentHistoryDTO>> GetAllPaymentHistoryAsync()
        {
            return await _paymentRepository.GetAllPaymentHistoryAsync();
        }

        public async Task<List<PaymentHistoryDTO>> GetPaymentHistoryByCustomerIdAsync(long customerId)
        {
            return await _paymentRepository.GetPaymentHistoryByCustomerIdAsync(customerId);
        }
    }
}
