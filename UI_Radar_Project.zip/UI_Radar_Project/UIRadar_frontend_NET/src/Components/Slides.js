import React from "react";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function Slides() {
  return (
    <div style={{ position: "relative", textAlign: "center" }}>
      <ToastContainer />

      <img
        src="./assests/image.png"
        alt="Banner"
        style={{
          zIndex: 1,
          width: "100%",
          height: "auto",
          maxHeight: "100vh",
          objectFit: "cover",
        }}
      />

      {/* Overlay Text */}
      <div
        style={{
          position: "absolute",
          top: "40%",
          left: "35%",
          transform: "translateY(-50%)",
          zIndex: 2,
          backgroundColor: "rgba(0, 0, 0, 0.55)", // blackish overlay
          padding: "20px 30px",
          borderRadius: "10px",
          maxWidth: "600px",
        }}
      >
        <h3
          style={{ color: "#ff7e5f", fontSize: "2rem", marginBottom: "0.5rem" }}
        >
          Understand Your Users Like Never Before
        </h3>
        <h1 style={{ fontSize: "1.5rem", margin: "0.5rem 0", color: "#fff" }}>
          Track Every Click & Scroll
        </h1>
        <h1 style={{ fontSize: "1.5rem", margin: "0.5rem 0", color: "#fff" }}>
          Visualize Behavior with Heatmaps
        </h1>
        <h1 style={{ fontSize: "1.5rem", margin: "0.5rem 0", color: "#fff" }}>
          Optimize Your UI for Conversions
        </h1>
      </div>
    </div>
  );
}

export default Slides;
